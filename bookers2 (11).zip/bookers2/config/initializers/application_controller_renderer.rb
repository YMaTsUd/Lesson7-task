# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'ff0c73f811bc8def0878c816aaf2f52d79497b97a0b266b9c724de45c0b10fea476279faceb4e4b3d589f461ec68027f2f95fa2af698aacf54be79ba9e4503c7'